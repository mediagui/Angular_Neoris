import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  texto: string = "Bienvenido al curso de Angular";
  fecha: Date = new Date();
  numero: number = 12345678.8765432578987643;
  jsonObjeto = {nombre:'Juan',edad:36,telefonos:{tel1:917651245,tel2:686123456}};
}
