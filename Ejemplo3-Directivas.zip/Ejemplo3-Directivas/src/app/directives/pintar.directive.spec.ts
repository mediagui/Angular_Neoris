import { PintarDirective } from './pintar.directive';

describe('PintarDirective', () => {
  it('should create an instance', () => {
    const directive = new PintarDirective();
    expect(directive).toBeTruthy();
  });
});
