import { Directive, Input, ElementRef, Renderer2, OnInit } from '@angular/core';

@Directive({
  selector: '[pintar]'
})
export class PintarDirective implements OnInit{
  @Input('pintar')
  preferencia: number = 0;

  constructor(private elRef: ElementRef,
    private renderer:Renderer2) { }

  ngOnInit(){
    if(this.preferencia == 1){
      this.renderer.setStyle(this.elRef.nativeElement,'color','green');
    } else if(this.preferencia == 2){
      this.renderer.setStyle(this.elRef.nativeElement,'color','orange');
    } else {
      this.renderer.setStyle(this.elRef.nativeElement,'color','red');
    }

  } 

}
