import { Directive, HostListener, HostBinding } from '@angular/core';

@Directive({
  selector: '[contarClicks]'
})
export class ContarClicksDirective {
  numeroPulsaciones: number = 0;

  constructor() { }

  @HostBinding('style.font-size')
  size:string = '';

  @HostBinding('style.opacity')
  opacity:number=0.1;

  @HostListener('click', ['$event.target'])
  onClick(animal){
    console.log(event.target);
    this.size = (20 + this.numeroPulsaciones) + 'px' ;
    this.opacity += 0.1;
    console.log("Animal: " + animal.innerHTML +
      " -- Numero de clicks: " + (++this.numeroPulsaciones) );
  } 

}
