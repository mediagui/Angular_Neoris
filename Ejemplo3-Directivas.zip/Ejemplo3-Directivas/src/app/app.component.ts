import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  animales:any = [
    {nombre: 'Perro',domestico:true,preferencia:1},
    {nombre: 'Gato',domestico:true,preferencia:3},
    {nombre: 'Pajaro',domestico:true,preferencia:3},
    {nombre: 'Leon',domestico:false,preferencia:2}
  ];
}
