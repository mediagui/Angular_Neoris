import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent implements OnInit {
  to: string = '';
  mensaje: string = '';

  constructor(private url: ActivatedRoute) {
    this.to = this.url.snapshot.queryParams['to'];
    this.mensaje = this.url.snapshot.queryParams['asunto'];
  }

  ngOnInit() {
  }

}
