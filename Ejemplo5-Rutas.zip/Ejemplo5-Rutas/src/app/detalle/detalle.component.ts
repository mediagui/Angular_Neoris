import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detalle',
  templateUrl: './detalle.component.html',
  styleUrls: ['./detalle.component.css']
})
export class DetalleComponent implements OnInit {

  codigo: number = 0;
  nombreUsuario: string = '';

  constructor(private url: ActivatedRoute) {
    console.log(this.url.snapshot.params['id']);
    this.codigo = this.url.snapshot.params['id'];
    this.nombreUsuario = this.url.snapshot.params['nombre'];
  }

  ngOnInit() {
  }

}
