import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { DetalleComponent } from './detalle/detalle.component';
import { ContactoComponent } from './contacto/contacto.component';

import { Routes, RouterModule } from '@angular/router';

// Array de rutas para hacer corresponder el path con el componente a mostrar
const misRutas: Routes = [
  {path:'', component:AppComponent},
  {path:'detalle/:id/:nombre', component:DetalleComponent},
  {path:'contacto', component:ContactoComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    DetalleComponent,
    ContactoComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
