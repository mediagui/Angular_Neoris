import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RecetasService {
  url: "http://176.655.54.12:8080/miAplicacion/servicioREST";
  bbdd = "https://gestioncroquetas.firebaseio.com"
  headers = new HttpHeaders({"Content-type":"application/json"});

  constructor(private http:HttpClient) { }

  public insertarReceta(receta){
    return this.http.post(this.bbdd + "/recetas.json", receta, {headers: this.headers});
  }

  public getRecetas(){
    return this.http.get(this.bbdd + "/recetas.json");
  }
}
