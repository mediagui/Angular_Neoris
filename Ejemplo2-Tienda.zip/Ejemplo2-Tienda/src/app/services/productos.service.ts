import { Injectable } from '@angular/core';
import { Producto } from '../modelos/producto';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {

  catalogo: Producto[] = [
    {id:1,nombre:'Croquetas de pollo',apto:'todos',precio:15,unidades:12, descatalogado: false,agotado:false},
    {id:2,nombre:'Croquetas de jamon',apto:'todos',precio:18,unidades:12, descatalogado: false,agotado:false},
    {id:3,nombre:'Croquetas de morcilla',apto:'todos',precio:20,unidades:10, descatalogado: false,agotado:true},
    {id:4,nombre:'Croquetas de queso',apto:'vegetariano',precio:10,unidades:6, descatalogado: true,agotado:false},
    {id:5,nombre:'Croquetas de boletus',apto:'vegano',precio:25,unidades:10, descatalogado: false,agotado:true},
    {id:6,nombre:'Croquetas de cocido',apto:'todos',precio:12,unidades:8, descatalogado: false,agotado:false}
  ]

  constructor() { }

  public getCatalogo(){
    return this.catalogo;
  }

  public buscarProducto(codigo){
    return this.catalogo.filter((producto) => {
      return producto.id == codigo
    })[0] || null;
    /*this.catalogo.forEach(element => {
      if (element.id == codigo){
        return element;
      }
    });*/
  }


}
