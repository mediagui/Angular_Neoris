import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { DescripcionComponent } from './descripcion/descripcion.component';
import { CatalogoComponent } from './catalogo/catalogo.component';

import { Routes, RouterModule} from '@angular/router';
import { PortadaComponent } from './portada/portada.component';

const misRutas: Routes = [
  {path:'inicio',component:PortadaComponent},
  {path:'todos',component:CatalogoComponent},
  {path:'detalle/:id',component:DescripcionComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    DescripcionComponent,
    CatalogoComponent,
    PortadaComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
