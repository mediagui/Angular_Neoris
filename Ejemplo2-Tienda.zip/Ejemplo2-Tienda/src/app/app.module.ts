import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { DescripcionComponent } from './descripcion/descripcion.component';
import { CatalogoComponent } from './catalogo/catalogo.component';

import { Routes, RouterModule} from '@angular/router';
import { PortadaComponent } from './portada/portada.component';

import { ProductosService } from './services/productos.service';
import { AuthenticationService } from './services/authentication.service';

import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { AngularFireStorageModule } from '@angular/fire/storage';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { environment } from '../environments/environment';
import { LoginComponent } from './login/login.component';
import { RecetaComponent } from './receta/receta.component';

const misRutas: Routes = [
  {path:'inicio',component:PortadaComponent},
  {path:'todos',component:CatalogoComponent},
  {path:'detalle/:id',component:DescripcionComponent},
  {path:'login',component:LoginComponent},
  {path:'share',component:RecetaComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    DescripcionComponent,
    CatalogoComponent,
    PortadaComponent,
    LoginComponent,
    RecetaComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas),
    AngularFireModule.initializeApp(environment.firebase),
    AngularFirestoreModule, // imports firebase/firestore, only needed for database features
    AngularFireAuthModule, // imports firebase/auth, only needed for auth features,
    AngularFireStorageModule, // imports firebase/storage only needed for storage features
    FormsModule
  ],
  providers: [ProductosService,AuthenticationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
