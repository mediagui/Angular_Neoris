import { Component, OnInit } from '@angular/core';
import { Receta } from '../modelos/receta';
import { RecetasService } from '../services/recetas.service';

@Component({
  selector: 'app-receta',
  templateUrl: './receta.component.html',
  styleUrls: ['./receta.component.css']
})
export class RecetaComponent {
  miReceta:Receta = {} as Receta;
  recetas:any = [];

  constructor(private recetasService: RecetasService) { 
    this.recetasService.getRecetas().subscribe((data) => {
      console.log(data);
       this.recetas = data;
       var me = this;
       me.recetas = Object.keys(me.recetas).map(function (key){
         return me.recetas[key];
       });
       console.log(this.recetas);
    });
  }

  guardar(){
    this.recetasService.insertarReceta(this.miReceta).subscribe(respuesta =>{
      console.log(this.miReceta);
    });
    
  }
}
