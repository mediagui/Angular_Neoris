import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  catalogo:any = [
    {nombre:'Croquetas de pollo',precio:15,unidades:12, descatalogado: false,agotado:false},
    {nombre:'Croquetas de jamon',precio:18,unidades:12, descatalogado: false,agotado:false},
    {nombre:'Croquetas de morcilla',precio:20,unidades:10, descatalogado: false,agotado:true},
    {nombre:'Croquetas de queso',precio:10,unidades:6, descatalogado: true,agotado:false},
    {nombre:'Croquetas de boletus',precio:25,unidades:10, descatalogado: false,agotado:true},
    {nombre:'Croquetas de cocido',precio:12,unidades:8, descatalogado: false,agotado:false}
  ]
}
