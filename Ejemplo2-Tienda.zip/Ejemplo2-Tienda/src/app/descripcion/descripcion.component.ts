import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Producto } from '../modelos/producto';
import { ProductosService } from '../services/productos.service';

@Component({
  selector: 'app-descripcion',
  templateUrl: './descripcion.component.html',
  styleUrls: ['./descripcion.component.css']
})
export class DescripcionComponent implements OnInit {

  producto:Producto = null;
  codigo:number = 0;

  constructor(private url: ActivatedRoute, private productosService: ProductosService) { 
    this.codigo = this.url.snapshot.params['id'];
    this.producto = productosService.buscarProducto(this.codigo);
  }

  ngOnInit() {
  }

}
