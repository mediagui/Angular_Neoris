import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-descripcion',
  templateUrl: './descripcion.component.html',
  styleUrls: ['./descripcion.component.css']
})
export class DescripcionComponent implements OnInit {

  producto:any = {};
  codigo:number = 0;

  catalogo:any = [
    {id:1,nombre:'Croquetas de pollo',apto:'todos',precio:15,unidades:12, descatalogado: false,agotado:false},
    {id:2,nombre:'Croquetas de jamon',apto:'todos',precio:18,unidades:12, descatalogado: false,agotado:false},
    {id:3,nombre:'Croquetas de morcilla',apto:'todos',precio:20,unidades:10, descatalogado: false,agotado:true},
    {id:4,nombre:'Croquetas de queso',apto:'vegetariano',precio:10,unidades:6, descatalogado: true,agotado:false},
    {id:5,nombre:'Croquetas de boletus',apto:'vegano',precio:25,unidades:10, descatalogado: false,agotado:true},
    {id:6,nombre:'Croquetas de cocido',apto:'todos',precio:12,unidades:8, descatalogado: false,agotado:false}
  ]

  constructor(private url: ActivatedRoute) { 
    this.codigo = this.url.snapshot.params['id'];
    this.buscarProducto();
  }

  buscarProducto(){
    this.catalogo.forEach(element => {
      if (element.id == this.codigo){
        this.producto = element;
      }
    });
  }

  ngOnInit() {
  }

}
