import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catalogo',
  templateUrl: './catalogo.component.html',
  styleUrls: ['./catalogo.component.css']
})
export class CatalogoComponent implements OnInit {
  catalogo:any = [
    {id:1,nombre:'Croquetas de pollo',precio:15,unidades:12, descatalogado: false,agotado:false},
    {id:2,nombre:'Croquetas de jamon',precio:18,unidades:12, descatalogado: false,agotado:false},
    {id:3,nombre:'Croquetas de morcilla',precio:20,unidades:10, descatalogado: false,agotado:true},
    {id:4,nombre:'Croquetas de queso',precio:10,unidades:6, descatalogado: true,agotado:false},
    {id:5,nombre:'Croquetas de boletus',precio:25,unidades:10, descatalogado: false,agotado:true},
    {id:6,nombre:'Croquetas de cocido',precio:12,unidades:8, descatalogado: false,agotado:false}
  ]

  constructor() { }

  ngOnInit() {
  }

}
