import { Component, OnInit } from '@angular/core';
import { ProductosService } from '../services/productos.service';

@Component({
  selector: 'app-catalogo',
  templateUrl: './catalogo.component.html',
  styleUrls: ['./catalogo.component.css']
})
export class CatalogoComponent implements OnInit {
  catalogo = null;

  constructor(private  productosService:ProductosService) { 
    this.catalogo = productosService.getCatalogo();
  }

  ngOnInit() {
  }

}
