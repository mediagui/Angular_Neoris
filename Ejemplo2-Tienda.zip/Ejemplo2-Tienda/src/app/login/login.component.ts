import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  operacion:string;
  email: string = '';
  pw: string = null;
  confirm_pw: string = '';

  constructor(private authenticationService:AuthenticationService) { 
    this.operacion = "login";
  }

  login(){
    this.authenticationService.logarse(this.email,this.pw).then((data) => {
      alert("Te has logado correctamente");
    }).catch((error) => {
      alert("Credenciales incorrectas");
      console.log(error);
    });
  }

  registro(){
    if(this.pw == this.confirm_pw){
      this.authenticationService.registrarse(this.email,this.pw).then((data) => {
        alert("Te has registrado correctamente");
      }).catch((error) => {
        alert("Este usuario ya existe");
        console.log(error);
      });
    } else {
      alert("Los password no coinciden");
    }  
  }

  ngOnInit() {
  }

}
