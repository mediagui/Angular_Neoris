export interface Producto{
    id: number;
    nombre: string;
    apto: string;
    precio: number;
    unidades: number;
    descatalogado: boolean;
    agotado: boolean;
}



//{id:1,nombre:'Croquetas de pollo',apto:'todos',precio:15,
//unidades:12, descatalogado: false,agotado:false},
    