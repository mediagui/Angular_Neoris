export interface Receta{
    nombre: string;
    comensales:number;
    dificultad:string;
    precio_comensal?:number;
    ingredientes:string;
    preparacion:string;
}