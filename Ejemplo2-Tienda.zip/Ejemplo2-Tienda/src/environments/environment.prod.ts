export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCocirS5fPr2Yfa5oxj2QativR5wEljQ3E",
    authDomain: "gestioncroquetas.firebaseapp.com",
    databaseURL: "https://gestioncroquetas.firebaseio.com",
    projectId: "gestioncroquetas",
    storageBucket: "gestioncroquetas.appspot.com",
    messagingSenderId: "283935033826",
    appId: "1:283935033826:web:8a6a30d022628019"
  }
};
