import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Bienvenidos al curso de Neoris';
  nombre = 'Anabel';
  apellido = 'Vegas';

  habilitado = false;

  texto: string = '';
  //texto = '';

  array:any=[
    {nombre:'Elemento 1', visible:true},
    {nombre:'Elemento 2', visible:false},
    {nombre:'Elemento 3', visible:true},
    {nombre:'Elemento 4', visible:false},
    {nombre:'Elemento 5', visible:true}
  ];

  mostrarMensaje(){
    alert("Hola");
    console.log("Probando mensajes en consola");
  }

  constructor(){
    setTimeout( () => {this.habilitado = true}  , 3000  );
  }
}
